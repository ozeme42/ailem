
"use client";

import * as React from "react";
import { useAuth } from "@/components/auth-provider";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { onSinglePrayerProgressUpdate, updatePrayerProgress } from "@/lib/dataService";
import type { PrayerProgress, FamilyMember } from "@/lib/data";
import { cn } from "@/lib/utils";
import { startOfWeek, addDays, format, subWeeks, addWeeks, isSameDay, parseISO } from 'date-fns';
import { tr } from 'date-fns/locale';
import { useToast } from "@/hooks/use-toast";
import { Heart, ChevronLeft, ChevronRight } from "lucide-react";

const prayerTimes = ["Sabah", "Öğle", "İkindi", "Akşam", "Yatsı"];

const dayLabels = [
    { full: "Pazartesi", short: "Pzt" },
    { full: "Salı", short: "Sal" },
    { full: "Çarşamba", short: "Çar" },
    { full: "Perşembe", short: "Per" },
    { full: "Cuma", short: "Cum" },
    { full: "Cumartesi", short: "Cmt" },
    { full: "Pazar", short: "Paz" }
];

export default function PrayerTrackerPage() {
    const { familyMembers } = useAuth();
    const [selectedMember, setSelectedMember] = React.useState<FamilyMember | null>(null);
    const [prayerProgress, setPrayerProgress] = React.useState<PrayerProgress | null>(null);
    const [currentDate, setCurrentDate] = React.useState(new Date());
    const { toast } = useToast();
    
    const weekStart = startOfWeek(currentDate, { weekStartsOn: 1 });
    const weekEnd = addDays(weekStart, 6);
    const weekDays = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

    React.useEffect(() => {
        if (familyMembers.length > 0 && !selectedMember) {
            const child = familyMembers.find(m => m.role.includes('Çocuk'));
            setSelectedMember(child || familyMembers[0]);
        }
    }, [familyMembers, selectedMember]);

    React.useEffect(() => {
        if (!selectedMember) return;

        const unsub = onSinglePrayerProgressUpdate(selectedMember.id, (progress) => {
            setPrayerProgress(progress);
        });

        return () => unsub();
    }, [selectedMember]);

    const handlePrayerToggle = async (dayKey: string, prayerName: string) => {
        if (!selectedMember) return;
    
        const allCompletions = JSON.parse(JSON.stringify(prayerProgress?.completions || {}));
    
        const dayCompletions: string[] = allCompletions[dayKey] || [];
        
        const isCompleted = dayCompletions.includes(prayerName);
        const newDayCompletions = isCompleted
            ? dayCompletions.filter((p: string) => p !== prayerName)
            : [...dayCompletions, prayerName];
            
        allCompletions[dayKey] = newDayCompletions;
    
        const newProgressState: PrayerProgress = {
            id: prayerProgress?.id || `${selectedMember.id}`,
            memberId: prayerProgress?.memberId || selectedMember.id,
            familyId: prayerProgress?.familyId || '', 
            completions: allCompletions,
        };
    
        setPrayerProgress(newProgressState);
        
        try {
            await updatePrayerProgress(selectedMember.id, allCompletions);
        } catch (error) {
            toast({
                title: "Hata",
                description: "Bir sorun oluştu, lütfen tekrar deneyin.",
                variant: "destructive"
            });
            console.error("Failed to update prayer progress:", error);
        }
    };
    
    return (
         <div className="h-full flex flex-col bg-gradient-to-b from-lime-300 via-yellow-200 to-yellow-300 dark:from-lime-900 dark:to-yellow-800 px-0 sm:px-4 py-4">
            <header className="text-center my-4">
                <h1 className="text-5xl font-extrabold text-white" style={{
                    textShadow: '3px 3px 0px #c026d3, 6px 6px 0px #a21caf',
                    fontFamily: "'Arial Black', sans-serif",
                }}>
                    Haftalık Namaz Tablom
                </h1>
            </header>
            
             <div className="flex flex-col items-center justify-center gap-4 mb-4 text-purple-800 dark:text-purple-200 font-semibold">
                <div className="flex gap-1">
                    <Heart className="size-6 text-red-500 fill-current"/>
                </div>
                <p>Kıldığın namazların kalbini kırmızıya boya.</p>
            </div>

            <div className="flex-grow flex items-center justify-center">
                 <div className="w-full max-w-4xl p-2 sm:p-4 bg-yellow-400 dark:bg-yellow-600 rounded-xl shadow-2xl border-4 border-yellow-500 dark:border-yellow-700">
                     <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-4">
                        <div className="flex items-center gap-2">
                           <Button variant="outline" size="icon" onClick={() => setCurrentDate(d => subWeeks(d, 1))}>
                               <ChevronLeft className="h-4 w-4" />
                           </Button>
                           <Button variant="outline" onClick={() => setCurrentDate(new Date())}>Bu Hafta</Button>
                           <Button variant="outline" size="icon" onClick={() => setCurrentDate(d => addWeeks(d, 1))}>
                               <ChevronRight className="h-4 w-4" />
                           </Button>
                        </div>
                        <p className="font-semibold text-center text-lg text-purple-900 dark:text-purple-100">
                           {format(weekStart, 'd MMMM', { locale: tr })} - {format(weekEnd, 'd MMMM yyyy', { locale: tr })}
                        </p>
                    </div>

                    <div className="grid grid-cols-6 gap-2 text-center text-white font-bold mb-2">
                        <div></div> {/* Empty corner */}
                        {prayerTimes.map(time => (
                            <div key={time} className="p-1 text-xs sm:text-base">{time}</div>
                        ))}
                    </div>
                    <div className="space-y-2">
                    {weekDays.map((day, dayIndex) => {
                        const dayKey = format(day, 'yyyy-MM-dd');
                        const completions = prayerProgress?.completions?.[dayKey] || [];
                        return(
                            <div key={dayKey} className="grid grid-cols-6 gap-2 items-center bg-white/80 dark:bg-gray-800/80 p-1.5 rounded-lg shadow-inner">
                                <div className="bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold rounded-full py-2 px-2 text-sm flex items-center justify-center shadow-md">
                                    <span className="hidden sm:inline">{dayLabels[dayIndex].full}</span>
                                    <span className="sm:hidden">{dayLabels[dayIndex].short}</span>
                                </div>
                                {prayerTimes.map(prayer => {
                                    const isCompleted = completions.includes(prayer);
                                    return (
                                        <div 
                                            key={prayer} 
                                            className="flex justify-center items-center cursor-pointer"
                                            onClick={() => handlePrayerToggle(dayKey, prayer)}
                                        >
                                            <Heart 
                                                className={cn("size-8 sm:size-10 transition-all hover:scale-110", isCompleted ? "text-red-500" : "text-gray-400/50")} 
                                                style={{ fill: isCompleted ? 'currentColor' : 'none' }}
                                            />
                                        </div>
                                    )
                                })}
                            </div>
                        )
                    })}
                    </div>
                 </div>
            </div>

            <div className="flex items-center justify-center gap-4 mt-8 pb-4 overflow-x-auto">
                {familyMembers.filter(m => m.role.includes("Çocuk")).map((member) => (
                    <Button
                        key={member.id}
                        variant={selectedMember?.id === member.id ? "default" : "secondary"}
                        className={cn(
                            "h-auto p-2 flex items-center gap-2 rounded-full transition-all duration-200 shrink-0 shadow-lg border-2",
                             selectedMember?.id === member.id && "scale-110 border-primary"
                        )}
                        onClick={() => setSelectedMember(member)}
                    >
                        <div 
                            className="w-8 h-8 rounded-full flex items-center justify-center text-lg font-bold" 
                            style={{ backgroundColor: member.color, color: '#fff' }}
                        >
                            {member.name.charAt(0).toUpperCase()}
                        </div>
                        <p className="font-bold text-base">{member.name}</p>
                    </Button>
                ))}
            </div>
         </div>
    );
}
